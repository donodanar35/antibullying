<?php

namespace DeepCopy\f008;

class B extends A
{
}
